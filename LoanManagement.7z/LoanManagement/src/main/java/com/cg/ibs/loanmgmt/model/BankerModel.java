package com.cg.ibs.loanmgmt.model;

import java.math.BigInteger;

public class BankerModel {

	private Integer bankerId;
	private String userId;
	private String password;
	private BigInteger verifyApplicationNumber;
	private BigInteger preClosureVerifyLoanNumber;
	private String remarks;		

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public BigInteger getVerifyApplicationNumber() {
		return verifyApplicationNumber;
	}

	public void setVerifyApplicationNumber(BigInteger verifyApplicationNumber) {
		this.verifyApplicationNumber = verifyApplicationNumber;
	}

	public BigInteger getPreClosureVerifyLoanNumber() {
		return preClosureVerifyLoanNumber;
	}

	public void setPreClosureVerifyLoanNumber(BigInteger preClosureVerifyLoanNumber) {
		this.preClosureVerifyLoanNumber = preClosureVerifyLoanNumber;
	}

	public Integer getBankerId() {
		return bankerId;
	}

	public void setBankerId(Integer bankerId) {
		this.bankerId = bankerId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
