package com.cg.ibs.loanmgmt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.ibs.loanmgmt.ui.User;

@SpringBootApplication
public class LoanManagementApplication implements CommandLineRunner {

	@Autowired
	private User user;

	public static void main(String[] args) {

		SpringApplication.run(LoanManagementApplication.class, args);

	}

	@Override
	public void run(String... args) throws Exception {

		 //user.applyLoan();
		// user.verifyLoan();
		//user.payEmi();
		//user.applyPreClosure();
		user.verifyPreClosure();
	}

}
